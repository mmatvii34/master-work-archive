﻿using StackExchange.Redis;

namespace RedisCacheOptimizer.Interfaces;

public interface IAdaptiveCacheClient : IDisposable
{
    Task StoreObjectAsync<T>(string key, T obj);
    Task<T> GetObjectAsync<T>(string key) where T : new();
    Task SetKeyTTLAsync(string key, TimeSpan ttl);
    Task SetPropertyTTLAsync(string key, string propertyPath, TimeSpan ttl);
    Task<TimeSpan?> GetKeyTTLAsync(string key);
    Task<TimeSpan?> GetPropertyTTLAsync(string key, string propertyPath);
    Task<RedisValue> HashGetAsync(RedisKey key, RedisValue field);
    Task<bool> HashSetAsync(RedisKey key, RedisValue field, RedisValue value);
    Task<bool> SetAddAsync(RedisKey key, RedisValue value);
    Task<bool> SetContainsAsync(RedisKey key, RedisValue value);
    Task<long> ListLeftPushAsync(RedisKey key, RedisValue value);
    Task<RedisValue> ListLeftPopAsync(RedisKey key);
    Task<RedisValue[]> ListRangeAsync(RedisKey key, long start = 0, long stop = -1);
    Task<bool> SortedSetAddAsync(RedisKey key, RedisValue member, double score);
    Task<RedisValue[]> SortedSetRangeByRankAsync(RedisKey key, long start = 0, long stop = -1);
    Task EnableProtectionAsync(string key, string propertyPath = null);
    Task DisableProtectionAsync(string key, string propertyPath = null);
}
