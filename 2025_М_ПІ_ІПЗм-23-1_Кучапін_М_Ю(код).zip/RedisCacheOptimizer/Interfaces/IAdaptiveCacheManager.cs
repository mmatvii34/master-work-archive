﻿namespace RedisCacheOptimizer.Interfaces;

public interface IAdaptiveCacheManager : IDisposable
{
    int EvictionCount { get; }

    Task CleanupForRequiredMemoryAsync(long requiredSize);

    void EnableCacheManager();

    void DisableCacheManager();

    void ClearEvictionCount();
}
