﻿using StackExchange.Redis;

namespace RedisCacheOptimizer.Models;

public class EvictionCandidate
{
    public RedisKey MetaKey { get; set; }
    public string DataKey { get; set; }

    public bool IsProperty { get; set; } 
    public string PropertyName { get; set; }
    public double Score { get; set; }
    public double MemoryUsage { get; set; } 
}
