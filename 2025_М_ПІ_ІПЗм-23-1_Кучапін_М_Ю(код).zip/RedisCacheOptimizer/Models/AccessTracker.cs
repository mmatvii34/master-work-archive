﻿namespace RedisCacheOptimizer.Models;

internal class AccessTracker
{
    public double Frequency { get; set; } = 0;
    public long LastAccess { get; set; } = long.MaxValue;
    public long LastFrequencyUpdateTime { get; set; }
}
