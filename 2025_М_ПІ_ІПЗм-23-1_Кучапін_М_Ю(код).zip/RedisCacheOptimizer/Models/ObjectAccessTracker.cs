﻿namespace RedisCacheOptimizer.Models;

internal class ObjectAccessTracker : AccessTracker
{
    public Dictionary<string, AccessTracker> PropertyAccessState { get; set; } = new Dictionary<string, AccessTracker>();
}
