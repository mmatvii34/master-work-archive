﻿namespace RedisCacheOptimizer.Models;

internal class PropertyPathPart
{
    public string Name { get; set; }
    public bool IsIndex { get; set; }
    public int Index { get; set; }
    public string Key { get; set; }
}
