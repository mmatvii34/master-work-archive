﻿using RedisCacheOptimizer.Configurations;
using RedisCacheOptimizer.Interfaces;
using RedisCacheOptimizer.Models;
using StackExchange.Redis;

namespace RedisCacheOptimizer;

public class AdaptiveCacheManager : BaseDatabaseClient, IAdaptiveCacheManager
{
    private readonly AdaptiveCacheManagerOptions _options;
    private CancellationTokenSource _cancellationTokenSource = new();
    private const double EPSILON = 1e-9;

    private readonly object _evictionSetLock = new object();
    private readonly object _updateEvictionScoreLock = new object();
    private readonly SemaphoreSlim _cleanupSemaphore = new SemaphoreSlim(1, 1);

    public int EvictionCount
    {
        get
        {
            return _evictionCount;
        }
    }

    private int _evictionCount;

    public AdaptiveCacheManager(string connectionString, AdaptiveCacheManagerOptions options) : base(connectionString)
    {
        _options = options;

        _options.Validate();

        if (Math.Abs(_options.AgeWeight + _options.FrequencyWeight + _options.MemoryWeight - 1.0) > 1e-9)
        {
            throw new ArgumentException("The sum of weight coefficients must equal 1.");
        }
    }

    public async Task CleanupForRequiredMemoryAsync(long requiredSize)
    {
        var server = _redis.GetServer(_redis.GetEndPoints()[0]);

        double memoryBufferPercentage = 0.15;
        long usedMemory = await GetUsedMemoryAsync(server);
        long maxMemory = await GetMaxMemoryAsync() ?? _options.MaxCacheMemory;

        long maxAllowedMemory = (long)(maxMemory * (1 - memoryBufferPercentage));

        if (usedMemory + requiredSize <= maxAllowedMemory)
        {
            return;
        }

        long memoryToFree = (usedMemory + requiredSize) - maxAllowedMemory;
        long freedSoFar = 0;

        while (memoryToFree > 0)
        {
            var batch = await _database.SortedSetRangeByScoreWithScoresAsync(
                Constants.GlobalEvictionSetKey,
                start: double.NegativeInfinity,
                stop: double.PositiveInfinity,
                order: Order.Ascending,
                take: 50
            );

            if (batch == null || batch.Length == 0)
            {
                break;
            }

            foreach (var entry in batch)
            {
                if (memoryToFree <= 0) break;

                lock (_evictionSetLock)
                {
                    _database.SortedSetRemove(Constants.GlobalEvictionSetKey, entry.Element);
                }

                string fullMember = entry.Element;
                if (string.IsNullOrEmpty(fullMember)) continue;

                string dataKey;
                string propertyName = null;

                if (fullMember.Contains("::"))
                {
                    var parts = fullMember.Split(new[] { "::" }, StringSplitOptions.None);
                    dataKey = parts[0];
                    propertyName = parts[1];
                }
                else
                {
                    dataKey = fullMember;
                }

                var isProtected = await _database.StringGetAsync(dataKey + Constants.ProtectedSuffix);
                if (isProtected == "true")
                {
                    continue;
                }

                var metaKey = (RedisKey)(dataKey + Constants.TtlHashSuffix);
                var memoryUsageResult = await _database.ExecuteAsync("MEMORY", "USAGE", dataKey);
                if (!long.TryParse(memoryUsageResult.ToString(), out var memorySize) || memorySize <= 0)
                {
                    memorySize = 1;
                }

                if (!string.IsNullOrEmpty(propertyName))
                {
                    await DeletePropertyAsync(dataKey, metaKey, propertyName);
                }
                else
                {
                    await DeleteKeyAsync(dataKey, metaKey);
                }

                freedSoFar += memorySize;
                memoryToFree -= memorySize;
                if (memoryToFree < 0)
                {
                    memoryToFree = 0;
                }
            }
        }

        if (memoryToFree > 0)
        {
            Console.WriteLine($"Warning: Unable to free enough memory. Still need {memoryToFree} bytes.");
        }
        else
        {
            Console.WriteLine($"Freed {freedSoFar} bytes to accommodate {requiredSize} bytes.");
        }
    }


    public void ClearEvictionCount()
    {
        _evictionCount = 0;
    }

    public void DisableCacheManager()
    {
        _cancellationTokenSource.Cancel();
    }

    public void EnableCacheManager()
    {
        _cancellationTokenSource = new();

        Task.Run(async () =>
        {
            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                try
                {
                    await CleanupExpiredKeysAsync();
                    await Task.Delay(_options.CleanupInterval, _cancellationTokenSource.Token);
                }
                catch (TaskCanceledException)
                {
                }
                catch (Exception ex)
                {
                    Log($"Error during CleanupExpiredKeys: {ex.Message}");
                }
            }
        }, _cancellationTokenSource.Token);
    }

    public async Task UpdateEvictionScoreAsync(string dataKey)
    {
        var metaKey = (RedisKey)(dataKey + Constants.TtlHashSuffix);
        var tracker = await GetObjectAccessTrackerAsync(metaKey);

        double now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        double freqGeneral = 0.0;
        double ageGeneral = 0.0;
        if (tracker.Frequency > 0)
        {
            double t = now - tracker.LastFrequencyUpdateTime;
            freqGeneral = tracker.Frequency * Math.Exp(-_options.DecayLambda * t);
            ageGeneral = now - tracker.LastAccess;
        }

        var memoryUsageResult = await _database.ExecuteAsync("MEMORY", "USAGE", dataKey);
        if (!long.TryParse(memoryUsageResult.ToString(), out var memorySize) || memorySize <= 0)
        {
            memorySize = 1;
        }

        double fMax = await GetFMaxAsync();
        double aMax = await GetAMaxAsync();
        long mMax = _options.MaxCacheMemory;

        double sKey = ComputeEvictionScore(ageGeneral, freqGeneral, memorySize, aMax, fMax, mMax);

        lock (_updateEvictionScoreLock)
        {
            _database.SortedSetAdd(Constants.GlobalEvictionSetKey, dataKey, sKey);
        }

        int propCount = tracker.PropertyAccessState.Count;
        if (propCount > 0)
        {
            double propertyMemoryShare = memorySize / (propCount + 1.0);

            foreach (var kvp in tracker.PropertyAccessState)
            {
                string propertyName = kvp.Key;
                var propTracker = kvp.Value;

                double freqProp = 0.0;
                double ageProp = 0.0;
                if (propTracker.Frequency > 0)
                {
                    double tProp = now - propTracker.LastFrequencyUpdateTime;
                    freqProp = propTracker.Frequency * Math.Exp(-_options.DecayLambda * tProp);
                    ageProp = now - propTracker.LastAccess;
                }

                double sProp = ComputeEvictionScore(ageProp, freqProp,
                                                    (long)propertyMemoryShare,
                                                    aMax, fMax, mMax);

                string zsetMember = $"{dataKey}::{propertyName}";

                lock (_updateEvictionScoreLock)
                {
                    _database.SortedSetAdd(Constants.GlobalEvictionSetKey, zsetMember, sProp);
                }
            }
        }
    }

    private async Task CleanupExpiredKeysAsync()
    {
        await _cleanupSemaphore.WaitAsync();
        try
        {
            var server = _redis.GetServer(_redis.GetEndPoints()[0]);

            long usedMemory = await GetUsedMemoryAsync(server);
            long maxMemory = await GetMaxMemoryAsync() ?? _options.MaxCacheMemory;

            long memoryThreshold = (long)(_options.PMemoryThreshold * maxMemory);

            if (usedMemory <= memoryThreshold)
            {
                return;
            }

            long memoryToFree = usedMemory - memoryThreshold;
            long freedSoFar = 0;

            while (memoryToFree > 0)
            {
                var batch = await _database.SortedSetRangeByScoreWithScoresAsync(
                    Constants.GlobalEvictionSetKey,
                    start: double.NegativeInfinity,
                    stop: double.PositiveInfinity,
                    order: Order.Ascending,
                    take: 50
                );

                if (batch == null || batch.Length == 0)
                {
                    break;
                }

                foreach (var entry in batch)
                {
                    if (memoryToFree <= 0) break;

                    lock (_evictionSetLock)
                    {
                        _database.SortedSetRemove(Constants.GlobalEvictionSetKey, entry.Element);
                    }

                    string fullMember = entry.Element;
                    if (string.IsNullOrEmpty(fullMember)) continue;

                    string dataKey;
                    string propertyName = null;

                    if (fullMember.Contains("::"))
                    {
                        var parts = fullMember.Split(new[] { "::" }, StringSplitOptions.None);
                        dataKey = parts[0];
                        propertyName = parts[1];
                    }
                    else
                    {
                        dataKey = fullMember;
                    }

                    var isProtected = await _database.StringGetAsync(dataKey + Constants.ProtectedSuffix);
                    if (isProtected == "true")
                    {
                        continue;
                    }

                    var metaKey = (RedisKey)(dataKey + Constants.TtlHashSuffix);

                    var memoryUsageResult = await _database.ExecuteAsync("MEMORY", "USAGE", dataKey);
                    if (!long.TryParse(memoryUsageResult.ToString(), out var memorySize) || memorySize <= 0)
                    {
                        memorySize = 1;
                    }

                    if (!string.IsNullOrEmpty(propertyName))
                    {
                        await DeletePropertyAsync(dataKey, metaKey, propertyName);
                    }
                    else
                    {
                        await DeleteKeyAsync(dataKey, metaKey);
                    }

                    freedSoFar += memorySize;
                    memoryToFree -= memorySize;
                    if (memoryToFree < 0)
                    {
                        memoryToFree = 0;
                    }
                }
            }

            if (memoryToFree > 0)
            {
                Console.WriteLine($"[CleanupExpiredKeys] Unable to free enough memory. Still need ~{memoryToFree} bytes.");
            }
            else
            {
                Console.WriteLine($"[CleanupExpiredKeys] Freed ~{freedSoFar} bytes; usedMemory was {usedMemory}, threshold is {memoryThreshold}.");
            }
        }
        finally
        {
            _cleanupSemaphore.Release();
        }
    }

    private double ComputeEvictionScore(double age, double frequency, long memorySize, double aMax, double fMax, long mMax)
    {
        double aNormalized = 0.0;
        if (aMax > 0)
        {
            aNormalized = Math.Min(age / aMax, 1.0);
        }

        double fNormalized = 0.0;
        if (fMax > 0)
        {
            fNormalized = Math.Min(frequency / fMax, 1.0);
        }

        double memInverted = (mMax > 0 && memorySize > 0)
            ? (mMax / (double)memorySize)
            : 1.0;

        double sAge = _options.AgeWeight * (1.0 / (aNormalized + EPSILON));
        double sFreq = _options.FrequencyWeight * fNormalized;
        double sMem = _options.MemoryWeight * memInverted;

        double S = sAge + sFreq + sMem;
        return Math.Max(S, 0.0);
    }

    private async Task<long> GetUsedMemoryAsync(IServer server)
    {
        try
        {
            var info = await server.InfoAsync("memory");
            var memoryInfo = info.FirstOrDefault(x => x.Key == "Memory");
            var usedMemoryString = memoryInfo?.FirstOrDefault(entry => entry.Key == "used_memory").Value;
            if (long.TryParse(usedMemoryString, out var usedMemory))
            {
                return usedMemory;
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error retrieving used memory: " + ex.Message);
        }
        return 0;
    }

    private async Task<long?> GetMaxMemoryAsync()
    {
        var server = _redis.GetServer(_redis.GetEndPoints()[0]);

        try
        {
            var config = await server.ConfigGetAsync("maxmemory");
            if (config != null && config.Length > 0)
            {
                var maxMemoryString = config.FirstOrDefault().Value;
                if (long.TryParse(maxMemoryString, out var maxMemory))
                {
                    return maxMemory > 0 ? maxMemory : long.MaxValue;
                }
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Error retrieving max memory: " + ex.Message);
        }
        return null;
    }

    private async Task<double> GetFMaxAsync()
    {
        var top = await _database.SortedSetRangeByRankWithScoresAsync(
            Constants.GlobalFrequencySetKey,
            0,
            0,
            Order.Descending);

        if (top != null && top.Length > 0)
        {
            return top[0].Score;
        }
        return 0.0;
    }

    private async Task<double> GetAMaxAsync()
    {
        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var bottom = await _database.SortedSetRangeByRankWithScoresAsync(
            Constants.GlobalLastAccessSetKey,
            0,
            0,
            Order.Ascending);

        if (bottom != null && bottom.Length > 0)
        {
            double minLastAccess = bottom[0].Score;
            double aMax = now - minLastAccess;
            return (aMax > 0) ? aMax : 0.0;
        }
        return 0.0;
    }

    private async Task<ObjectAccessTracker> GetObjectAccessTrackerAsync(RedisKey metaKey)
    {
        var objectAccessTracker = new ObjectAccessTracker();
        var entries = await _database.HashGetAllAsync(metaKey);

        foreach (var entry in entries)
        {
            string field = entry.Name;
            string value = entry.Value;

            if (field == "frequency")
            {
                objectAccessTracker.Frequency = double.Parse(value);
            }
            else if (field == "lastAccess")
            {
                objectAccessTracker.LastAccess = long.Parse(value);
            }
            else if (field == "lastFrequencyUpdateTime")
            {
                objectAccessTracker.LastFrequencyUpdateTime = long.Parse(value);
            }
            else if (field.Contains(":"))
            {
                var parts = field.Split(':');
                if (parts.Length == 2)
                {
                    string propertyName = parts[0];
                    string propertyField = parts[1];

                    if (!objectAccessTracker.PropertyAccessState.TryGetValue(propertyName, out var tracker))
                    {
                        tracker = new AccessTracker();
                        objectAccessTracker.PropertyAccessState[propertyName] = tracker;
                    }

                    if (propertyField == "frequency")
                    {
                        tracker.Frequency = double.Parse(value);
                    }
                    else if (propertyField == "lastAccess")
                    {
                        tracker.LastAccess = long.Parse(value);
                    }
                    else if (propertyField == "lastFrequencyUpdateTime")
                    {
                        tracker.LastFrequencyUpdateTime = long.Parse(value);
                    }
                }
            }
        }

        return objectAccessTracker;
    }

    private async Task DeleteKeyAsync(string dataKey, RedisKey metaKey)
    {
        var typeResult = await _database.ExecuteAsync("TYPE", dataKey);
        string keyType = typeResult.ToString();

        if (keyType == "hash")
        {
            var deleteDataTask = _database.KeyDeleteAsync(dataKey);
            var deleteMetaTask = _database.KeyDeleteAsync(metaKey);
            await Task.WhenAll(deleteDataTask, deleteMetaTask);
        }
        else
        {
            await _database.KeyDeleteAsync(dataKey);
            await _database.KeyDeleteAsync(metaKey);
        }

        Interlocked.Increment(ref _evictionCount);

        await _database.SortedSetRemoveAsync(Constants.GlobalFrequencySetKey, dataKey);
        await _database.SortedSetRemoveAsync(Constants.GlobalLastAccessSetKey, dataKey);
        await _database.SortedSetRemoveAsync(Constants.GlobalEvictionSetKey, dataKey);
    }

    private async Task DeletePropertyAsync(string dataKey, RedisKey metaKey, string propertyName)
    {
        var typeResult = await _database.ExecuteAsync("TYPE", dataKey);
        string keyType = typeResult.ToString();

        if (keyType == "hash")
        {
            var deleteDataTask = _database.HashDeleteAsync(dataKey, propertyName);
            var deleteMetaTask = _database.HashDeleteAsync(metaKey, new RedisValue[]
            {
                $"{propertyName}:frequency",
                $"{propertyName}:lastAccess",
                $"{propertyName}:lastFrequencyUpdateTime"
            });
            await Task.WhenAll(deleteDataTask, deleteMetaTask);
        }
        else
        {
            await _database.KeyDeleteAsync(dataKey);
            await _database.KeyDeleteAsync(metaKey);
        }

        Interlocked.Increment(ref _evictionCount);

        string propertyMember = $"{dataKey}::{propertyName}";

        await _database.SortedSetRemoveAsync(Constants.GlobalFrequencySetKey, propertyMember);
        await _database.SortedSetRemoveAsync(Constants.GlobalLastAccessSetKey, propertyMember);
        await _database.SortedSetRemoveAsync(Constants.GlobalEvictionSetKey, propertyMember);
    }

    public void Dispose()
    {
    }
}
