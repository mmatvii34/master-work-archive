﻿using System.Text.Json;

namespace RedisCacheOptimizer.Utilities;

public static class SizeEstimator
{
    public static long CalculateObjectSizeInBytes<T>(T obj)
    {
        if (obj == null)
        {
            return 0;
        }

        var serialized = JsonSerializer.Serialize(obj);

        return System.Text.Encoding.UTF8.GetByteCount(serialized);
    }
}
