﻿using System.Collections;
using System.Globalization;

namespace RedisCacheOptimizer.Utilities;

internal static class Utility
{
    internal static string ConvertToString(object value)
    {
        if (value == null)
            return null;

        switch (value)
        {
            case DateTime dt:
                return dt.ToString("o", CultureInfo.InvariantCulture);
            case DateTimeOffset dto:
                return dto.ToString("o", CultureInfo.InvariantCulture);
            case TimeSpan ts:
                return ts.ToString("c", CultureInfo.InvariantCulture);
            case Guid guid:
                return guid.ToString();
            case Enum _:
                return value.ToString();
            case IFormattable formattable:
                return formattable.ToString(null, CultureInfo.InvariantCulture);
            default:
                return value.ToString();
        }
    }

    internal static object ConvertFromString(string value, Type type)
    {
        if (type.IsEnum)
        {
            return Enum.Parse(type, value);
        }

        if (type == typeof(Guid))
        {
            return Guid.Parse(value);
        }

        if (type == typeof(DateTime))
        {
            return DateTime.Parse(value, null, DateTimeStyles.RoundtripKind);
        }

        if (type == typeof(DateTimeOffset))
        {
            return DateTimeOffset.Parse(value, null, DateTimeStyles.RoundtripKind);
        }

        if (type == typeof(TimeSpan))
        {
            return TimeSpan.ParseExact(value, "c", CultureInfo.InvariantCulture);
        }

        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
        {
            if (string.IsNullOrEmpty(value))
                return null;

            type = Nullable.GetUnderlyingType(type);
        }

        if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(List<>))
        {
            var itemType = type.GetGenericArguments()[0];
            var items = value.Split(new[] { ',' }, StringSplitOptions.RemoveEmptyEntries)
                             .Select(item => ConvertFromString(item.Trim(), itemType))
                             .ToList();
            var list = (IList)Activator.CreateInstance(type);
            foreach (var item in items)
            {
                list.Add(item);
            }
            return list;
        }

        return Convert.ChangeType(value, type, CultureInfo.InvariantCulture);
    }

    internal static bool IsSimpleType(Type type)
    {
        Type[] simpleTypes =
        {
            typeof(string), typeof(decimal),
            typeof(DateTime), typeof(DateTimeOffset),
            typeof(TimeSpan), typeof(Guid)
        };
        var underlyingType = Nullable.GetUnderlyingType(type) ?? type;

        return underlyingType.IsPrimitive
            || underlyingType.IsEnum
            || simpleTypes.Contains(underlyingType)
            || Convert.GetTypeCode(underlyingType) != TypeCode.Object;
    }
}
