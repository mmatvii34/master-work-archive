﻿using System.Collections;
using System.Reflection;
using System.Text.RegularExpressions;
using RedisCacheOptimizer.Models;

namespace RedisCacheOptimizer.Utilities;

internal static class ObjectSerializer
{
    internal static Dictionary<string, string> FlattenObject(object obj, string parentPath = "")
    {
        var result = new Dictionary<string, string>();
        if (obj == null)
            return result;

        Type type = obj.GetType();

        if (Utility.IsSimpleType(type))
        {
            result[parentPath] = Utility.ConvertToString(obj);
        }
        else if (typeof(IDictionary).IsAssignableFrom(type))
        {
            var dict = (IDictionary)obj;
            foreach (DictionaryEntry entry in dict)
            {
                var keyPath = $"{parentPath}[{Utility.ConvertToString(entry.Key)}]";
                if (Utility.IsSimpleType(entry.Value.GetType()))
                {
                    result[keyPath] = Utility.ConvertToString(entry.Value);
                }
                else
                {
                    var nestedProperties = FlattenObject(entry.Value, keyPath);
                    foreach (var kvp in nestedProperties)
                    {
                        result[kvp.Key] = kvp.Value;
                    }
                }
            }
        }
        else if (typeof(IEnumerable).IsAssignableFrom(type) && type != typeof(string))
        {
            int index = 0;
            foreach (var item in (IEnumerable)obj)
            {
                var itemPath = $"{parentPath}[{index}]";
                if (Utility.IsSimpleType(item.GetType()))
                {
                    result[itemPath] = Utility.ConvertToString(item);
                }
                else
                {
                    var nestedProperties = FlattenObject(item, itemPath);
                    foreach (var kvp in nestedProperties)
                    {
                        result[kvp.Key] = kvp.Value;
                    }
                }
                index++;
            }
        }
        else if (type.IsGenericType && type.GetGenericTypeDefinition() == typeof(Nullable<>))
        {
            if (obj != null)
            {
                result[parentPath] = Utility.ConvertToString(obj);
            }
        }
        else if (type.IsClass || type.IsValueType)
        {
            foreach (var prop in type.GetProperties(BindingFlags.Public | BindingFlags.Instance))
            {
                if (prop.GetIndexParameters().Length > 0)
                    continue;

                var value = prop.GetValue(obj);
                var propertyPath = string.IsNullOrEmpty(parentPath) ? prop.Name : $"{parentPath}.{prop.Name}";

                if (value == null)
                    continue;

                if (Utility.IsSimpleType(prop.PropertyType))
                {
                    result[propertyPath] = Utility.ConvertToString(value);
                }
                else
                {
                    var nestedProperties = FlattenObject(value, propertyPath);
                    foreach (var kvp in nestedProperties)
                    {
                        result[kvp.Key] = kvp.Value;
                    }
                }
            }
        }
        else
        {
            throw new NotSupportedException($"Type '{type.FullName}' is not supported for flattening.");
        }

        return result;
    }

    internal static T UnflattenObject<T>(Dictionary<string, string> properties) where T : new()
    {
        T obj = new T();
        foreach (var kvp in properties)
        {
            SetPropertyValue(obj, kvp.Key, kvp.Value);
        }
        return obj;
    }

    private static void SetPropertyValue(object obj, string propertyPath, string value)
    {
        var parts = SplitPropertyPath(propertyPath);
        object currentObj = obj;

        for (int i = 0; i < parts.Count; i++)
        {
            var part = parts[i];

            if (!part.IsIndex)
            {
                Type currentType = currentObj.GetType();
                var propInfo = currentType.GetProperty(part.Name);
                if (propInfo == null)
                {
                    return;
                }

                if (i == parts.Count - 1)
                {
                    if (propInfo.CanWrite)
                    {
                        object convertedValue = Utility.ConvertFromString(value, propInfo.PropertyType);
                        propInfo.SetValue(currentObj, convertedValue);
                    }
                }
                else
                {
                    object nextObj = propInfo.GetValue(currentObj);
                    if (nextObj == null)
                    {
                        if (propInfo.PropertyType.IsGenericType && propInfo.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>))
                        {
                            return;
                        }
                        else
                        {
                            nextObj = Activator.CreateInstance(propInfo.PropertyType);
                            propInfo.SetValue(currentObj, nextObj);
                        }
                    }
                    currentObj = nextObj;
                }
            }
            else
            {
                Type collectionType = currentObj.GetType();
                Type elementType = null;

                if (typeof(IDictionary).IsAssignableFrom(collectionType))
                {
                    var dict = currentObj as IDictionary;
                    var key = Utility.ConvertFromString(part.Key, dict.GetType().GetGenericArguments()[0]);

                    if (i == parts.Count - 1)
                    {
                        var valueType = dict.GetType().GetGenericArguments()[1];
                        var convertedValue = Utility.ConvertFromString(value, valueType);
                        dict[key] = convertedValue;
                    }
                    else
                    {
                        if (!dict.Contains(key))
                        {
                            var valueType = dict.GetType().GetGenericArguments()[1];
                            var newValue = Activator.CreateInstance(valueType);
                            dict[key] = newValue;
                        }
                        currentObj = dict[key];
                    }
                }
                else if (typeof(IList).IsAssignableFrom(collectionType))
                {
                    elementType = collectionType.IsGenericType
                        ? collectionType.GetGenericArguments()[0]
                        : typeof(object);
                    var list = currentObj as IList;

                    int index = part.Index;

                    while (list.Count <= index)
                    {
                        list.Add(CreateInstanceOfListItemType(elementType));
                    }

                    if (i == parts.Count - 1)
                    {
                        var convertedValue = Utility.ConvertFromString(value, elementType);
                        list[index] = convertedValue;
                    }
                    else
                    {
                        currentObj = list[index];
                    }
                }
                else
                {
                    return;
                }
            }
        }
    }

    private static List<PropertyPathPart> SplitPropertyPath(string propertyPath)
    {
        var parts = new List<PropertyPathPart>();
        var regex = new Regex(@"(\w+)|\[(.*?)\]");
        var matches = regex.Matches(propertyPath);

        foreach (Match match in matches)
        {
            if (!string.IsNullOrEmpty(match.Groups[1].Value))
            {
                parts.Add(new PropertyPathPart { Name = match.Groups[1].Value });
            }
            else if (!string.IsNullOrEmpty(match.Groups[2].Value))
            {
                var indexer = match.Groups[2].Value;
                if (int.TryParse(indexer, out int index))
                {
                    parts.Add(new PropertyPathPart { IsIndex = true, Index = index });
                }
                else
                {
                    parts.Add(new PropertyPathPart { IsIndex = true, Key = indexer });
                }
            }
        }

        return parts;
    }

    private static object CreateInstanceOfListItemType(Type itemType)
    {
        if (itemType == typeof(string))
        {
            return string.Empty;
        }
        if (itemType.IsValueType)
        {
            return Activator.CreateInstance(itemType);
        }
        return Activator.CreateInstance(itemType);
    }
}
