﻿using StackExchange.Redis;

namespace RedisCacheOptimizer;

public class BaseDatabaseClient
{
    protected readonly ConnectionMultiplexer _redis;
    protected readonly IDatabase _database;

    public BaseDatabaseClient(string connectionString)
    {
        var configuration = ConfigurationOptions.Parse(connectionString);
        configuration.AsyncTimeout = 950000;
        configuration.SyncTimeout = 950000;

        _redis = ConnectionMultiplexer.Connect(configuration);
        _database = _redis.GetDatabase();
    }

    public void Log(string message)
    {
        Console.WriteLine(message);
    }
}
