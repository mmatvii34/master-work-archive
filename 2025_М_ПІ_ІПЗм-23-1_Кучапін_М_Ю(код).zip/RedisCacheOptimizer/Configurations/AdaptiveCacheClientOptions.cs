﻿namespace RedisCacheOptimizer.Configurations;

public class AdaptiveCacheClientOptions
{
    public TimeSpan MaxTTL { get; set; } = TimeSpan.FromHours(1);
    public TimeSpan BaseTTL { get; set; } = TimeSpan.FromMinutes(1);
    public double DecayLambda { get; set; } = 0.5;
    public TimeSpan CleanupInterval { get; set; } = TimeSpan.FromMinutes(1);

    public AdaptiveCacheManagerOptions AdaptiveCacheManagerOptions { get; set; } = new AdaptiveCacheManagerOptions();

    public void Validate()
    {
        if (MaxTTL <= TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(MaxTTL), "MaxTTL must be greater than zero.");

        if (BaseTTL <= TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(BaseTTL), "BaseTTL must be greater than zero.");

        if (DecayLambda <= 0)
            throw new ArgumentOutOfRangeException(nameof(DecayLambda), "DecayLambda must be greater than or equal zero.");

        if (CleanupInterval <= TimeSpan.Zero)
            throw new ArgumentOutOfRangeException(nameof(CleanupInterval), "CleanupInterval must be greater than zero.");
    }
}
