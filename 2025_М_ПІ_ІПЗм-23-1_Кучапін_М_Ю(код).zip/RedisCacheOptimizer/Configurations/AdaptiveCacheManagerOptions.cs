﻿namespace RedisCacheOptimizer.Configurations;

public class AdaptiveCacheManagerOptions
{
    public TimeSpan CleanupInterval { get; set; } = TimeSpan.FromMinutes(1);
    public double AgeWeight { get; set; } = 0.4;
    public double FrequencyWeight { get; set; } = 0.4;
    public double MemoryWeight { get; set; } = 0.2;
    public long MaxCacheMemory { get; set; } = 1024 * 1024 * 1024;
    public double DecayLambda { get; set; }
    public double PMemoryThreshold { get; set; }

    public void Validate()
    {
        if (CleanupInterval <= TimeSpan.Zero)
            throw new ArgumentException("CleanupInterval must be greater than zero.");
        if (AgeWeight < 0 || AgeWeight > 1)
            throw new ArgumentException("AgeWeight must be in the range from 0 to 1.");
        if (FrequencyWeight < 0 || FrequencyWeight > 1)
            throw new ArgumentException("FrequencyWeight must be in the range from 0 to 1.");
        if (MemoryWeight < 0 || MemoryWeight > 1)
            throw new ArgumentException("MemoryWeight must be in the range from 0 to 1.");
        if (Math.Abs(AgeWeight + FrequencyWeight + MemoryWeight - 1) > 0.0001)
            throw new ArgumentException("The sum of the weighting factors must equal 1.");
        if (MaxCacheMemory <= 0)
            throw new ArgumentException("MaxCacheMemory must be greater than zero.");
    }
}
