﻿namespace RedisCacheOptimizer.Configurations;

public class Constants
{
    public const string TtlHashSuffix = ":ttl:hash";
    public const string TtlSortedSetSuffix = ":ttl:sorted";
    public const string ProtectedSuffix = ":protected";
    public const string GlobalFrequencySetKey = "GlobalFrequencySet";
    public const string GlobalLastAccessSetKey = "GlobalLastAccessSet";
    public const string GlobalEvictionSetKey = "GlobalEvictionSet";
    public const int MIN_METADATA_UPDATE_INTERVAL = 5;
}
