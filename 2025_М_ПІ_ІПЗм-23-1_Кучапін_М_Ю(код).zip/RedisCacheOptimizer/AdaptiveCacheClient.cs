﻿using RedisCacheOptimizer.Configurations;
using RedisCacheOptimizer.Interfaces;
using RedisCacheOptimizer.Utilities;
using StackExchange.Redis;

namespace RedisCacheOptimizer;

public class AdaptiveCacheClient : BaseDatabaseClient, IAdaptiveCacheClient
{
    private readonly AdaptiveCacheClientOptions _options;
    private CancellationTokenSource _cancellationTokenSource = new();
    public AdaptiveCacheManager CacheManager;
    private readonly SemaphoreSlim _cleanupSemaphore = new SemaphoreSlim(1, 1);

    public int ExpiredKeys
    {
        get
        {
            return _expiredKeys;
        }
    }

    private int _expiredKeys;

    public AdaptiveCacheClient(string connectionString, AdaptiveCacheClientOptions options) : base(connectionString)
    {
        options.Validate();

        _options = options;

        CacheManager = new AdaptiveCacheManager(connectionString, options.AdaptiveCacheManagerOptions);

        StartBackgroundCleanup();
    }

    public async Task StoreObjectAsync<T>(string key, T obj)
    {
        await HandleInsertWithMemoryManagementAsync(key, obj, async () =>
        {
            var hashEntries = ObjectSerializer.FlattenObject(obj)
                .Select(kvp => new HashEntry(kvp.Key, kvp.Value))
                .ToArray();

            await _database.HashSetAsync(key, hashEntries);
            await UpdateKeyAccessAsync(key, false);
        });
    }

    public async Task<T> GetObjectAsync<T>(string key) where T : new()
    {
        var hashEntries = await _database.HashGetAllAsync(key);
        if (hashEntries.Length == 0)
            return default;

        var properties = hashEntries.ToDictionary(entry => (string)entry.Name, entry => (string)entry.Value);

        var obj = ObjectSerializer.UnflattenObject<T>(properties);

        await UpdateKeyAccessAsync(key, true);

        return obj;
    }

    public async Task SetKeyTTLAsync(string key, TimeSpan ttl)
    {
        await SetPropertyTTLAsync(key, string.Empty, ttl);
    }

    public async Task SetPropertyTTLAsync(string key, string propertyPath, TimeSpan ttl)
    {
        var sortedSetKey = key + Constants.TtlSortedSetSuffix;
        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        var expiryTime = now + (long)ttl.TotalSeconds;

        await _database.SortedSetAddAsync(sortedSetKey, propertyPath, expiryTime);

        Log($"TTL for property '{propertyPath}' is set to {ttl.TotalSeconds} seconds.");
    }

    public async Task<RedisValue> HashGetAsync(RedisKey key, RedisValue field)
    {
        var value = await _database.HashGetAsync(key, field);
        if (!value.IsNull)
        {
            await UpdatePropertyAccessAsync(key, field);
        }

        return value;
    }

    public async Task<bool> HashSetAsync(RedisKey key, RedisValue field, RedisValue value)
    {
        var combinedObject = new { Field = field.ToString(), Value = value.ToString() };

        bool operationResult = false;

        await HandleInsertWithMemoryManagementAsync(key, combinedObject, async () =>
        {
            operationResult = await _database.HashSetAsync(key, field, value);

            await UpdatePropertyAccessAsync(key, field);
        });

        return operationResult;
    }

    public async Task<bool> SetAddAsync(RedisKey key, RedisValue value)
    {
        bool operationResult = false;

        await HandleInsertWithMemoryManagementAsync(key, value.ToString(), async () =>
        {
            operationResult = await _database.SetAddAsync(key, value);

            if (operationResult)
            {
                await UpdatePropertyAccessAsync(key, value);
            }
        });

        return operationResult;
    }

    public async Task<bool> SetContainsAsync(RedisKey key, RedisValue value)
    {
        var exists = await _database.SetContainsAsync(key, value);

        if (exists)
        {
            await UpdatePropertyAccessAsync(key, value);
        }

        return exists;
    }

    public async Task<long> ListLeftPushAsync(RedisKey key, RedisValue value)
    {
        long result = 0;

        await HandleInsertWithMemoryManagementAsync(key, value.ToString(), async () =>
        {
            result = await _database.ListLeftPushAsync(key, value);
            await UpdatePropertyAccessAsync(key, value);
        });

        return result;
    }

    public async Task<RedisValue> ListLeftPopAsync(RedisKey key)
    {
        var value = await _database.ListLeftPopAsync(key);
        if (!value.IsNull)
        {
            await RemoveElementMetadataAsync(key, value);
        }
        return value;
    }

    public async Task<RedisValue[]> ListRangeAsync(RedisKey key, long start = 0, long stop = -1)
    {
        var values = await _database.ListRangeAsync(key, start, stop);
        foreach (var value in values)
        {
            await UpdatePropertyAccessAsync(key, value);
        }
        return values;
    }

    public async Task<bool> SortedSetAddAsync(RedisKey key, RedisValue member, double score)
    {
        var combinedObject = new { Member = member.ToString(), Score = score };
        bool operationResult = false;

        await HandleInsertWithMemoryManagementAsync(key, combinedObject, async () =>
        {
            operationResult = await _database.SortedSetAddAsync(key, member, score);

            if (operationResult)
            {
                await UpdatePropertyAccessAsync(key, member);
            }
        });

        return operationResult;
    }

    public async Task<RedisValue[]> SortedSetRangeByRankAsync(RedisKey key, long start = 0, long stop = -1)
    {
        var values = await _database.SortedSetRangeByRankAsync(key, start, stop);
        foreach (var value in values)
        {
            await UpdatePropertyAccessAsync(key, value);
        }
        return values;
    }

    public async Task<TimeSpan?> GetKeyTTLAsync(string key)
    {
        return await GetPropertyTTLAsync(key, string.Empty);
    }

    public async Task<TimeSpan?> GetPropertyTTLAsync(string key, string propertyPath)
    {
        var sortedSetKey = key + Constants.TtlSortedSetSuffix;
        var expiryTimestamp = await _database.SortedSetScoreAsync(sortedSetKey, propertyPath);

        if (expiryTimestamp.HasValue)
        {
            var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            var ttlSeconds = expiryTimestamp.Value - now;

            if (ttlSeconds > 0)
            {
                return TimeSpan.FromSeconds(ttlSeconds);
            }
            else
            {
                return TimeSpan.Zero;
            }
        }

        return null;
    }

    public async Task EnableProtectionAsync(string key, string propertyPath = null)
    {
        await SetProtectionAsync(key, propertyPath, true);
    }

    public async Task DisableProtectionAsync(string key, string propertyPath = null)
    {
        await SetProtectionAsync(key, propertyPath, false);
    }

    public void Dispose()
    {
        StopBackgroundCleanup();
        _redis?.Dispose();
    }

    private async Task HandleInsertWithMemoryManagementAsync<T>(string key, T value, Func<Task> insertAction)
    {
        long estimatedSize = SizeEstimator.CalculateObjectSizeInBytes(value);
        long adjustedSize = (long)(estimatedSize * 1.5);

        await CacheManager.CleanupForRequiredMemoryAsync(adjustedSize);

        await insertAction();
    }

    private async Task SetProtectionAsync(string key, string propertyPath, bool enable)
    {
        if (string.IsNullOrEmpty(propertyPath))
        {
            if (enable)
            {
                await _database.StringSetAsync(key + Constants.ProtectedSuffix, "true");
                Log($"Protection enabled for key '{key}'.");
            }
            else
            {
                await _database.KeyDeleteAsync(key + Constants.ProtectedSuffix);
                Log($"Protection disabled for key '{key}'.");
            }
        }
        else
        {
            var metaKey = key + Constants.TtlHashSuffix;
            var field = propertyPath + ":protected";
            if (enable)
            {
                await _database.HashSetAsync(metaKey, field, "true");
                Log($"Protection enabled for property '{propertyPath}' in key '{key}'.");
            }
            else
            {
                await _database.HashDeleteAsync(metaKey, field);
                Log($"Protection disabled for property '{propertyPath}' in key '{key}'.");
            }
        }
    }

    private async Task UpdateKeyAccessAsync(string key, bool recalculateTtl)
    {
        var metaKey = key + Constants.TtlHashSuffix;
        var frequency = await UpdateAccessStatsAsync(metaKey, "key");

        await CacheManager.UpdateEvictionScoreAsync(key);

        var lastAccessValue = await _database.HashGetAsync(metaKey, "lastAccess");
        var shouldBeUpdated = true;

        if (recalculateTtl && shouldBeUpdated)
        {
            var sortedSetKey = key + Constants.TtlSortedSetSuffix;
            var existingTTL = await _database.SortedSetScoreAsync(sortedSetKey, string.Empty);

            if (existingTTL.HasValue)
            {
                TimeSpan ttl = await ComputeAdaptiveTTLAsync(metaKey, "key");

                var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
                var expiryTime = now + (long)ttl.TotalSeconds;

                await _database.SortedSetAddAsync(sortedSetKey, string.Empty, expiryTime);
                Log($"Adaptive TTL for key '{key}' recalculated: {ttl.TotalSeconds} seconds.");
            }
            else
            {
                Log($"Key '{key}' does not have a TTL set. Skipping adaptive TTL.");
            }
        }
    }

    private async Task UpdatePropertyAccessAsync(string key, string propertyPath)
    {
        var metaKey = key + Constants.TtlHashSuffix;

        await UpdateKeyAccessAsync(key, true);

        var frequency = await UpdateAccessStatsAsync(metaKey, propertyPath);

        var lastAccessValue = await _database.HashGetAsync(metaKey, $"{propertyPath}:lastAccess");
        var shouldBeUpdated = lastAccessValue.IsNullOrEmpty || DateTimeOffset.UtcNow.ToUnixTimeSeconds() - (long)lastAccessValue > Constants.MIN_METADATA_UPDATE_INTERVAL;

        if (shouldBeUpdated)
        {
            var sortedSetKey = key + Constants.TtlSortedSetSuffix;
            var existingTTL = await _database.SortedSetScoreAsync(sortedSetKey, propertyPath);

            if (existingTTL.HasValue)
            {
                var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

                TimeSpan ttl = await ComputeAdaptiveTTLAsync(metaKey, propertyPath);
                var expiryTime = now + (long)ttl.TotalSeconds;

                await _database.SortedSetAddAsync(sortedSetKey, propertyPath, expiryTime);
                Log($"Adaptive TTL for property '{propertyPath}' recalculated: {ttl.TotalSeconds} seconds.");
            }
            else
            {
                Log($"Property '{propertyPath}' does not have a TTL set. Skipping adaptive TTL.");
            }
        }
    }

    private async Task<double> UpdateAccessStatsAsync(string metaKey, string accessKey)
    {
        var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

        var dataKey = metaKey.Replace(Constants.TtlHashSuffix, "");
        string prefix = accessKey == "key" ? "" : accessKey + ":";
        string totalAccessesField = $"{prefix}totalAccesses";
        string firstAccessTimeField = $"{prefix}firstAccessTime";
        string lastAccessField = $"{prefix}lastAccess";
        string frequencyField = $"{prefix}frequency";

        var firstAccessTimeValue = await _database.HashGetAsync(metaKey, firstAccessTimeField);

        long totalAccesses = await _database.HashIncrementAsync(metaKey, totalAccessesField, 1);
        long firstAccessTime = firstAccessTimeValue.IsNullOrEmpty ? now : (long)firstAccessTimeValue;

        await _database.HashSetAsync(metaKey, new HashEntry[]
        {
            new HashEntry(totalAccessesField, totalAccesses),
            new HashEntry(firstAccessTimeField, firstAccessTime),
            new HashEntry(lastAccessField, now)
        });

        double elapsedTime = now - firstAccessTime;
        double frequency = elapsedTime > 0 ? totalAccesses / elapsedTime : totalAccesses;

        await _database.HashSetAsync(metaKey, frequencyField, frequency);

        string totalAccessSetMember = (accessKey == "key")
            ? dataKey
            : $"{dataKey}::{accessKey}";

        await _database.SortedSetAddAsync(Constants.GlobalFrequencySetKey, totalAccessSetMember, totalAccesses);
        await _database.SortedSetAddAsync(Constants.GlobalLastAccessSetKey, totalAccessSetMember, now);


        return frequency;
    }

    private async Task<TimeSpan> ComputeAdaptiveTTLAsync(string metaKey, string accessKey)
    {
        string prefix = (accessKey == "key") ? "" : (accessKey + ":");
        string totalAccessesField = $"{prefix}totalAccesses";
        string lastAccessField = $"{prefix}lastAccess";

        var totalAccessesValue = await _database.HashGetAsync(metaKey, totalAccessesField);
        var lastAccessValue = await _database.HashGetAsync(metaKey, lastAccessField);

        long f = totalAccessesValue.IsNullOrEmpty ? 0 : (long)totalAccessesValue;
        long tLastAccess = lastAccessValue.IsNullOrEmpty
            ? DateTimeOffset.UtcNow.ToUnixTimeSeconds()
            : (long)lastAccessValue;

        double now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
        double f_decayed = f * Math.Exp(-_options.DecayLambda * (now - tLastAccess));

        double maxTotalAccesses = 0;
        var totalAccessSetRange = await _database.SortedSetRangeByRankWithScoresAsync(
            Constants.GlobalFrequencySetKey,
            0,
            0,
            Order.Descending);

        if (totalAccessSetRange != null && totalAccessSetRange.Length > 0)
        {
            maxTotalAccesses = totalAccessSetRange[0].Score;
        }

        double f_normalized = (maxTotalAccesses > 0)
            ? Math.Min(f_decayed / maxTotalAccesses, 1.0)
            : 0.0;

        var ttlSec = _options.BaseTTL + (_options.MaxTTL - _options.BaseTTL) * f_normalized;
        return ttlSec;
    }

    private void StopBackgroundCleanup()
    {
        _cancellationTokenSource.Cancel();
    }

    private void StartBackgroundCleanup()
    {
        Task.Run(async () =>
        {
            while (!_cancellationTokenSource.Token.IsCancellationRequested)
            {
                try
                {
                    await CleanupExpiredPropertiesAsync();
                    await Task.Delay(_options.CleanupInterval, _cancellationTokenSource.Token);
                }
                catch (TaskCanceledException)
                {
                }
                catch (Exception ex)
                {
                    Log($"Error during CleanupExpiredProperties: {ex.Message}");
                }
            }
        }, _cancellationTokenSource.Token);
    }

    private async Task CleanupExpiredPropertiesAsync()
    {
        await _cleanupSemaphore.WaitAsync();
        try
        {
            var server = _redis.GetServer(_redis.GetEndPoints()[0]);
            var keys = server.Keys(pattern: "*" + Constants.TtlSortedSetSuffix);

            var now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();

            foreach (var key in keys)
            {
                var dataKey = key.ToString().Replace(Constants.TtlSortedSetSuffix, "");
                var expiredProperties = await _database.SortedSetRangeByScoreAsync(key, 0, now);

                if (expiredProperties.Length > 0)
                {
                    foreach (var propertyPath in expiredProperties)
                    {
                        Log($"The '{propertyPath}' property for the key '{dataKey}' was deleted after the TTL expired.");

                        await RemovePropertyAndSubPropertiesAsync(dataKey, key, propertyPath);
                        Interlocked.Increment(ref _expiredKeys);
                    }
                }
            }
        }
        catch (Exception ex)
        {
            Log("Error during CleanupExpiredProperties: " + ex.Message);
        }
        finally
        {
            _cleanupSemaphore.Release();
        }
    }

    private async Task RemovePropertyAndSubPropertiesAsync(string dataKey, RedisKey ttlSortedSetKey, RedisValue propertyPath)
    {
        var hashFields = await _database.HashKeysAsync(dataKey);

        var fieldsToDelete = hashFields.Where(field => field.ToString().StartsWith(propertyPath.ToString())).ToArray();

        if (fieldsToDelete.Length > 0)
        {
            await _database.HashDeleteAsync(dataKey, fieldsToDelete);

            var metaKey = dataKey + Constants.TtlHashSuffix;
            var metaFieldsToDelete = fieldsToDelete.SelectMany(field => new RedisValue[]
            {
                $"{field}:frequency",
                $"{field}:lastAccess",
                $"{field}:lastFrequencyUpdateTime"
            }).ToArray();

            await _database.HashDeleteAsync(metaKey, metaFieldsToDelete);
            await _database.SortedSetRemoveAsync(ttlSortedSetKey, fieldsToDelete);

            var members = fieldsToDelete.Select(field => new RedisValue($"{dataKey}::{field}")).ToArray();
            await _database.SortedSetRemoveAsync(Constants.GlobalFrequencySetKey, members);
            await _database.SortedSetRemoveAsync(Constants.GlobalLastAccessSetKey, members);
            await _database.SortedSetRemoveAsync(Constants.GlobalEvictionSetKey, members);
        }
        else
        {
            await _database.HashDeleteAsync(dataKey, propertyPath);
            await _database.SortedSetRemoveAsync(ttlSortedSetKey, propertyPath);

            var metaKey = dataKey + Constants.TtlHashSuffix;
            await _database.HashDeleteAsync(metaKey, new RedisValue[]
            {
                $"{propertyPath}:frequency",
                $"{propertyPath}:lastAccess",
                $"{propertyPath}:lastFrequencyUpdateTime"
            });

            var members = fieldsToDelete.Select(field => new RedisValue($"{dataKey}::{field}")).ToArray();

            if (members.Length > 0)
            {
                await _database.SortedSetRemoveAsync(Constants.GlobalFrequencySetKey, members);
                await _database.SortedSetRemoveAsync(Constants.GlobalLastAccessSetKey, members);
                await _database.SortedSetRemoveAsync(Constants.GlobalEvictionSetKey, members);
            }

            string member = string.IsNullOrEmpty(propertyPath) ? dataKey : $"{dataKey}::{propertyPath}";
            await _database.SortedSetRemoveAsync(Constants.GlobalFrequencySetKey, member);
            await _database.SortedSetRemoveAsync(Constants.GlobalLastAccessSetKey, member);
            await _database.SortedSetRemoveAsync(Constants.GlobalEvictionSetKey, member);
        }
    }

    private async Task RemoveElementMetadataAsync(RedisKey key, RedisValue field)
    {
        var metaKey = key.ToString() + Constants.TtlHashSuffix;
        await _database.HashDeleteAsync(metaKey, new RedisValue[]
        {
            $"{field}:frequency",
            $"{field}:lastAccess",
            $"{field}:lastFrequencyUpdateTime"
        });
        var sortedSetKey = key.ToString() + Constants.TtlSortedSetSuffix;
        await _database.SortedSetRemoveAsync(sortedSetKey, field);

        string members = $"{key.ToString()}::{field}";
        await _database.SortedSetRemoveAsync(Constants.GlobalFrequencySetKey, members);
        await _database.SortedSetRemoveAsync(Constants.GlobalLastAccessSetKey, members);
        await _database.SortedSetRemoveAsync(Constants.GlobalEvictionSetKey, members);
    }
}
