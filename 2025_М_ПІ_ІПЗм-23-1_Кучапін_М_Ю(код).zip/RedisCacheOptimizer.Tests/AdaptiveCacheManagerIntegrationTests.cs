﻿using StackExchange.Redis;
using RedisCacheOptimizer.Configurations;
using Constants = RedisCacheOptimizer.Tests.Configurations.Constants;

namespace RedisCacheOptimizer.Tests;

public class AdaptiveCacheManagerIntegrationTests
{
    private AdaptiveCacheClientOptions _options;

    public AdaptiveCacheManagerIntegrationTests()
    {
        _options = new AdaptiveCacheClientOptions
        {
            MaxTTL = TimeSpan.FromSeconds(10),
            BaseTTL = TimeSpan.FromSeconds(1),
            DecayLambda = 0.4,
            CleanupInterval = TimeSpan.FromMilliseconds(200),
            AdaptiveCacheManagerOptions = new AdaptiveCacheManagerOptions
            {
                CleanupInterval = TimeSpan.FromSeconds(5),
                AgeWeight = 0.4,
                FrequencyWeight = 0.4,
                MemoryWeight = 0.2,
                DecayLambda = 0.4,
                MaxCacheMemory = 1024 * 1024 * 1024,
                PMemoryThreshold = 0.1
            }
        };
    }

    [Fact]
    public void Constructor_ValidOptions_ShouldCreateInstance()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            Assert.NotNull(client.CacheManager);
        }
    }

    [Fact]
    public void Constructor_InvalidWeightsSum_ShouldThrowException()
    {
        var invalidOptions = new AdaptiveCacheClientOptions
        {
            MaxTTL = _options.MaxTTL,
            BaseTTL = _options.BaseTTL,
            DecayLambda = _options.DecayLambda,
            CleanupInterval = _options.CleanupInterval,

            AdaptiveCacheManagerOptions = new AdaptiveCacheManagerOptions
            {
                CleanupInterval = TimeSpan.FromSeconds(5),
                AgeWeight = 0.5,
                FrequencyWeight = 0.5,
                MemoryWeight = 0.5, // Сума 1.5
                DecayLambda = 0.4,
                MaxCacheMemory = 1024,
                PMemoryThreshold = 0.1
            }
        };

        Assert.Throws<ArgumentException>(() =>
        {
            using (var client = new AdaptiveCacheClient(Constants.ConnectionString, invalidOptions))
            {
            }
        });
    }

    [Fact]
    public void Constructor_InvalidCleanupInterval_ShouldThrowException()
    {
        var invalidOptions = new AdaptiveCacheClientOptions
        {
            MaxTTL = _options.MaxTTL,
            BaseTTL = _options.BaseTTL,
            DecayLambda = _options.DecayLambda,
            CleanupInterval = _options.CleanupInterval,
            AdaptiveCacheManagerOptions = new AdaptiveCacheManagerOptions
            {
                CleanupInterval = TimeSpan.Zero,
                AgeWeight = 0.4,
                FrequencyWeight = 0.4,
                MemoryWeight = 0.2,
                DecayLambda = 0.4,
                MaxCacheMemory = 1024,
                PMemoryThreshold = 0.1
            }
        };

        Assert.Throws<ArgumentException>(() =>
        {
            using (var client = new AdaptiveCacheClient(Constants.ConnectionString, invalidOptions))
            {
            }
        });
    }

    [Fact]
    public async Task Cleanup_NoKeys_NoError()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            client.CacheManager.EnableCacheManager();

            await Task.Delay(_options.CleanupInterval.Add(TimeSpan.FromSeconds(2)));

            Assert.NotNull(client.CacheManager);
        }
    }

    [Fact]
    public async Task Cleanup_ProtectedKey_ShouldNotEvict()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            client.CacheManager.EnableCacheManager();

            using var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            string key = "ProtectedKeyTest";
            await db.StringSetAsync(key, "SomeValue");
            await db.StringSetAsync(key + ":protected", "true");

            string metaKey = key + ":ttl:hash";
            await db.HashSetAsync(metaKey, new HashEntry[]
            {
                new HashEntry("frequency", "10"),
                new HashEntry("lastAccess", ((long)(DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 10)).ToString()),
                new HashEntry("lastFrequencyUpdateTime", ((long)(DateTimeOffset.UtcNow.ToUnixTimeSeconds()-10)).ToString())
            });

            await Task.Delay(_options.AdaptiveCacheManagerOptions.CleanupInterval.Add(TimeSpan.FromSeconds(2)));

            var val = await db.StringGetAsync(key);
            Assert.False(val.IsNullOrEmpty, "Protected key must not be evicted.");
        }
    }

    [Fact]
    public async Task Cleanup_NonProtectedKey_MayEvictLargeKey()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            client.CacheManager.EnableCacheManager();

            using var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            string key = "EvictKeyTest";
            string largeValue = new string('X', 10000);
            await db.StringSetAsync(key, largeValue);

            string metaKey = key + ":ttl:hash";
            await db.HashSetAsync(metaKey, new HashEntry[]
            {
                new HashEntry("frequency", "0.1"),
                new HashEntry("lastAccess", ((long)(DateTimeOffset.UtcNow.ToUnixTimeSeconds() - 1000)).ToString()),
                new HashEntry("lastFrequencyUpdateTime", ((long)(DateTimeOffset.UtcNow.ToUnixTimeSeconds()-1000)).ToString())
            });

            await Task.Delay(_options.AdaptiveCacheManagerOptions.CleanupInterval.Add(TimeSpan.FromSeconds(2)));

            Assert.True(true);
        }
    }

    [Fact]
    public async Task Cleanup_HighFrequencyKey_ShouldNotEvict()
    {
        _options.AdaptiveCacheManagerOptions.AgeWeight = 0.1;
        _options.AdaptiveCacheManagerOptions.FrequencyWeight = 0.8;
        _options.AdaptiveCacheManagerOptions.MemoryWeight = 0.1;

        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            client.CacheManager.EnableCacheManager();

            using var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            string key = "HighFreqKeyTest";
            await db.StringSetAsync(key, "Value");

            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            string metaKey = key + ":ttl:hash";
            await db.HashSetAsync(metaKey, new HashEntry[]
            {
                new HashEntry("frequency", "50"),
                new HashEntry("lastAccess", now.ToString()),
                new HashEntry("lastFrequencyUpdateTime", now.ToString())
            });

            await Task.Delay(_options.AdaptiveCacheManagerOptions.CleanupInterval.Add(TimeSpan.FromSeconds(1)));

            var val = await db.StringGetAsync(key);
            Assert.False(val.IsNullOrEmpty, "High frequency key should not be evicted.");
        }
    }

    [Fact]
    public async Task Cleanup_PropertyEviction()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            client.CacheManager.EnableCacheManager();

            using var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            string key = "PropertyEvictTest";
            await db.HashSetAsync(key, new HashEntry[]
            {
                new HashEntry("Prop1", "Value1"),
                new HashEntry("Prop2", "Value2")
            });

            string metaKey = key + ":ttl:hash";
            long now = DateTimeOffset.UtcNow.ToUnixTimeSeconds();
            await db.HashSetAsync(metaKey, new HashEntry[]
            {
                new HashEntry("frequency", "0.5"),
                new HashEntry("lastAccess", (now - 500).ToString()),
                new HashEntry("lastFrequencyUpdateTime", (now - 500).ToString()),

                new HashEntry("Prop2:frequency", "0.01"),
                new HashEntry("Prop2:lastAccess", (now - 1000).ToString()),
                new HashEntry("Prop2:lastFrequencyUpdateTime", (now - 1000).ToString())
            });

            await Task.Delay(_options.AdaptiveCacheManagerOptions.CleanupInterval.Add(TimeSpan.FromSeconds(2)));

            var hash = await db.HashGetAllAsync(key);
            var props = hash.ToDictionary(x => x.Name.ToString(), x => x.Value.ToString());

            Assert.True(true);
        }
    }

    [Fact]
    public void Dispose_ShouldNotThrow()
    {
        var client = new AdaptiveCacheClient(Constants.ConnectionString, _options);
        client.Dispose();

        Assert.True(true);
    }

    [Fact]
    public async Task Cleanup_WithLargeMaxMemory_NoErrors()
    {
        var largeManagerOptions = new AdaptiveCacheManagerOptions
        {
            CleanupInterval = TimeSpan.FromSeconds(5),
            AgeWeight = 0.4,
            FrequencyWeight = 0.4,
            MemoryWeight = 0.2,
            DecayLambda = 0.4,
            MaxCacheMemory = 10L * 1024 * 1024 * 1024,
            PMemoryThreshold = 0.1
        };

        var largeOptions = new AdaptiveCacheClientOptions
        {
            MaxTTL = _options.MaxTTL,
            BaseTTL = _options.BaseTTL,
            DecayLambda = _options.DecayLambda,
            CleanupInterval = _options.CleanupInterval,
            AdaptiveCacheManagerOptions = largeManagerOptions
        };

        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, largeOptions))
        {
            client.CacheManager.EnableCacheManager();

            using var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            await db.StringSetAsync("LargeMemKey1", "Data");
            await db.StringSetAsync("LargeMemKey2", "Data");

            await Task.Delay(largeManagerOptions.CleanupInterval.Add(TimeSpan.FromSeconds(2)));

            Assert.True(true);
        }
    }
}
