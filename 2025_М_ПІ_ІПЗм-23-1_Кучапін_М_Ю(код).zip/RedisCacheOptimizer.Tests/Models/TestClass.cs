﻿namespace RedisCacheOptimizer.Tests.Models;

public class TestClass
{
    public int Id { get; set; }
    public string Name { get; set; }
}
