﻿namespace RedisCacheOptimizer.Tests.Configurations;

public static class Constants
{
    public const string ConnectionString = "localhost:6380";
}
