﻿using StackExchange.Redis;
using RedisCacheOptimizer.Configurations;
using RedisCacheOptimizer.Tests.Models;
using Constants = RedisCacheOptimizer.Tests.Configurations.Constants;

namespace RedisCacheOptimizer.Tests;

public class AdaptiveCacheClientIntegrationTests
{
    private readonly AdaptiveCacheClientOptions _options;

    public AdaptiveCacheClientIntegrationTests()
    {
        _options = new AdaptiveCacheClientOptions
        {
            MaxTTL = TimeSpan.FromSeconds(10),
            BaseTTL = TimeSpan.FromSeconds(1),
            DecayLambda = 0.4,
            CleanupInterval = TimeSpan.FromMilliseconds(200)
        };
    }

    [Fact]
    public async Task StoreAndGetObjectAsync_ShouldRoundTripSuccessfully()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var testObject = new TestClass { Id = 42, Name = "IntegrationTest" };
            await client.StoreObjectAsync("IntegrationTestKey", testObject);

            var retrieved = await client.GetObjectAsync<TestClass>("IntegrationTestKey");
            Assert.NotNull(retrieved);
            Assert.Equal(42, retrieved.Id);
            Assert.Equal("IntegrationTest", retrieved.Name);
        }
    }

    [Fact]
    public async Task GetObjectAsync_NoData_ReturnsDefault()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var result = await client.GetObjectAsync<TestClass>("NonExistentKey");
            Assert.Null(result);
        }
    }

    [Fact]
    public async Task SetAndGetPropertyTTLAsync_ShouldSetTTL_WithAdaptiveComputation()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var testObject = new TestClass { Id = 100, Name = "TTLTest" };
            await client.StoreObjectAsync("TestKey", testObject);

            var initialTtl = TimeSpan.FromSeconds(10);
            await client.SetPropertyTTLAsync("TestKey", "Name", initialTtl);

            var retrievedTtl = await client.GetPropertyTTLAsync("TestKey", "Name");
            Assert.NotNull(retrievedTtl);
            Assert.True(retrievedTtl.Value.TotalSeconds > 0,
                "TTL must be > 0");

            Assert.True(retrievedTtl.Value <= _options.MaxTTL,
                $"TTL should not exceed {_options.MaxTTL.TotalSeconds} seconds.");

            Assert.True(retrievedTtl.Value >= _options.BaseTTL,
                $"TTL must be at least {_options.BaseTTL.TotalSeconds} seconds.");
        }
    }

    [Fact]
    public async Task EnableDisableProtectionAsync_ShouldWorkAsExpected()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            await client.EnableProtectionAsync("ProtectedKey");

            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            var val = await db.StringGetAsync("ProtectedKey:protected");
            Assert.Equal("true", val.ToString());

            await client.DisableProtectionAsync("ProtectedKey");
            val = await db.StringGetAsync("ProtectedKey:protected");

            Assert.True(val.IsNullOrEmpty);
        }
    }

    [Fact]
    public async Task HashSetAndGetAsync_ShouldSetAndGetValue()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            await client.HashSetAsync("HashTestKey", "Field1", "Value1");
            var val = await client.HashGetAsync("HashTestKey", "Field1");

            Assert.Equal("Value1", val.ToString());
        }
    }

    [Fact]
    public async Task ListPushAndPopAsync_ShouldAddAndRemoveElement()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            await client.ListLeftPushAsync("ListTestKey", "Item1");

            var popped = await client.ListLeftPopAsync("ListTestKey");
            Assert.Equal("Item1", popped.ToString());
        }
    }

    [Fact]
    public async Task ListRangeAsync_ShouldReturnPushedItems()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            string listKey = "ListRangeTestKey";

            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            await redis.GetDatabase().KeyDeleteAsync(listKey);

            await client.ListLeftPushAsync(listKey, "Item1");
            await client.ListLeftPushAsync(listKey, "Item2");

            var items = await client.ListRangeAsync(listKey);
            var values = items.Select(i => i.ToString()).ToArray();

            Assert.Contains("Item1", values);
            Assert.Contains("Item2", values);
        }
    }

    [Fact]
    public async Task SetAddAndContainsAsync_ShouldWorkAsExpected()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            await db.KeyDeleteAsync("SetTestKey");

            var added = await client.SetAddAsync("SetTestKey", "Member1");
            Assert.True(added);

            var exists = await client.SetContainsAsync("SetTestKey", "Member1");
            Assert.True(exists);
        }
    }

    [Fact]
    public async Task SortedSetAddAndRangeAsync_ShouldReturnMembers()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();
            await db.KeyDeleteAsync("SortedSetTestKey");

            await client.SortedSetAddAsync("SortedSetTestKey", "Member1", 1);
            await client.SortedSetAddAsync("SortedSetTestKey", "Member2", 2);

            var members = await client.SortedSetRangeByRankAsync("SortedSetTestKey");
            var memberStr = members.Select(m => m.ToString()).ToArray();

            Assert.Contains("Member1", memberStr);
            Assert.Contains("Member2", memberStr);
        }
    }

    [Fact]
    public void EnableDisableCacheManager_ShouldNotThrow()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            client.CacheManager.EnableCacheManager();
            client.CacheManager.DisableCacheManager();
        }
    }

    [Fact]
    public void Dispose_ShouldDisposeTimersAndConnection()
    {
        var client = new AdaptiveCacheClient(Constants.ConnectionString, _options);
        client.Dispose();
        Assert.True(true);
    }

    [Fact]
    public async Task SetProtectionAsync_PropertyPath_ShouldSetAndUnsetProtection()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();

            string key = "ProtectionPropertyTestKey";
            string property = "SomeProp";

            await db.HashSetAsync(key, property, "Value");

            await InvokeSetProtectionAsync(client, key, property, enable: true);

            var metaKey = key + ":ttl:hash";
            var protectedField = await db.HashGetAsync(metaKey, property + ":protected");
            Assert.Equal("true", protectedField.ToString());

            await InvokeSetProtectionAsync(client, key, property, enable: false);
            protectedField = await db.HashGetAsync(metaKey, property + ":protected");
            Assert.True(protectedField.IsNullOrEmpty);
        }
    }

    private async Task InvokeSetProtectionAsync(AdaptiveCacheClient client, string key, string property, bool enable)
    {
        if (enable)
            await client.EnableProtectionAsync(key, property);
        else
            await client.DisableProtectionAsync(key, property);
    }

    [Fact]
    public async Task UpdateKeyAccessAsync_WithExistingTTL_ShouldRecalculateTTL()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();
            string key = "UpdateKeyAccessTestKey";

            await db.KeyDeleteAsync(key);

            await client.StoreObjectAsync(key, new TestClass { Id = 1, Name = "Test" });

            await db.KeyExpireAsync(key, TimeSpan.FromSeconds(30));

            await client.GetObjectAsync<TestClass>(key);

            var ttlAfter = await db.KeyTimeToLiveAsync(key);
            Assert.NotNull(ttlAfter);
            Assert.True(ttlAfter.Value > TimeSpan.Zero, "After access update, TTL should be > 0.");
        }
    }

    [Fact]
    public async Task CleanupExpiredProperties_ShouldRemoveExpiredProperty()
    {
        using (var client = new AdaptiveCacheClient(Constants.ConnectionString, _options))
        {
            var redis = ConnectionMultiplexer.Connect(Constants.ConnectionString);
            var db = redis.GetDatabase();
            string key = "CleanupExpiredPropertyTestKey";
            string property = "Name";
            var ttl = TimeSpan.FromSeconds(10);

            await db.KeyDeleteAsync(key);
            await db.KeyDeleteAsync(key + ":ttl:hash");
            await db.KeyDeleteAsync(key + ":ttl:sorted");

            await client.StoreObjectAsync(key, new TestClass { Id = 1, Name = "ValueForCleanup" });

            var type = await db.ExecuteAsync("TYPE", key);
            Assert.Equal("hash", type.ToString());

            await client.SetPropertyTTLAsync(key, property, ttl);

            var typeAfterSetTTL = await db.ExecuteAsync("TYPE", key);
            Assert.Equal("hash", typeAfterSetTTL.ToString());

            var sortedSetKey = key + ":ttl:sorted";
            var sortedSetMembers = await db.SortedSetRangeByScoreAsync(sortedSetKey, 0, double.MaxValue);
            Assert.Contains(property, sortedSetMembers.Select(v => v.ToString()));

            await Task.Delay(ttl.Add(_options.CleanupInterval));
            
            var hashEntries = await db.HashGetAllAsync(key);
            var propExists = hashEntries.Any(e => e.Name.ToString() == property);
            Assert.False(propExists, "The field should be deleted after the TTL expires and cleaning starts.");
        }
    }
}
