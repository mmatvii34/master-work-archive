﻿using System.Diagnostics;
using RedisCacheOptimizer.Configurations;
using RedisCacheOptimizer;
using StackExchange.Redis;

namespace RedisExperiment
{
    public class ComplexObject
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public DateTime Timestamp { get; set; }
        public string Payload { get; set; }

        public ComplexObject()
        {
            Payload = new string('X', 3000);
        }
    }

    public class ExperimentRunner
    {
        private readonly string _connectionString;
        private readonly ConnectionMultiplexer _redis;
        private readonly IDatabase _database;
        private readonly List<Dictionary<string, object>> _results;

        private const int DefaultMemoryLimitMB = 50;
        private const int ReadRatio = 80;

        public ExperimentRunner(string connectionString)
        {
            _connectionString = connectionString;
            _redis = ConnectionMultiplexer.Connect(connectionString);
            _database = _redis.GetDatabase();
            _results = new List<Dictionary<string, object>>();
        }

        public async Task Run()
        {
            try
            {
                Console.WriteLine("Starting Redis Experiments...");

                var datasetSizes = new[] { 10000 };

                var strategies = new Dictionary<string, string>
                {
                    { "Adaptive", "noeviction" },
                    { "LRU", "allkeys-lru" },
                    { "LFU", "allkeys-lfu" },
                    { "RandomEviction", "allkeys-random" },
                };

                foreach (var strategy in strategies)
                {
                    foreach (var size in datasetSizes)
                    {
                        Console.WriteLine($"Testing strategy: {strategy.Key} with dataset size: {size}");

                        int memoryLimitMB = CalculateMemoryLimit(size, strategy.Key);

                        await RunExperiments(strategy.Key, strategy.Value, size, memoryLimitMB);

                        await CleanAllDatabases();
                    }

                    SaveResultsToCsv($"experiment_results_{strategy.Key}.csv");
                }

                SaveResultsToCsv("experiment_results.csv");
                Console.WriteLine("All Experiments Completed.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                SaveResultsToCsv("experiment_results.csv");
            }
        }


        private async Task RunExperiments(string strategyName,
                                  string evictionPolicy,
                                  int datasetSize,
                                  int memoryLimitMB)
        {
            ConfigureRedisPolicy(evictionPolicy, memoryLimitMB);

            var options = GetDefaultAdaptiveCacheClientOptions();
            options.AdaptiveCacheManagerOptions.MaxCacheMemory = memoryLimitMB * 1024L * 1024L;

            object cacheClient = strategyName == "Adaptive"
                ? new AdaptiveCacheClient(_connectionString, options)
                : null;

            var (hitCount, missCount, averageFreshness, minTTL, maxTTL, evictionCount, expiredKeys) = await RunMainExperiment(strategyName, cacheClient, datasetSize);

            var(writeTime, readTime, averageWriteTime, averageReadTime)
                = await RunOperationTimesExperiment(strategyName, cacheClient, datasetSize);

            var memoryResults = await RunMemoryUsageExperiment(strategyName, cacheClient, datasetSize);

            var cpuUsagePercent = await RunCPUUsageExperiment(strategyName, cacheClient, datasetSize);

            var deltaWorkingSet = await RunRAMUsageExperiment(strategyName, cacheClient, datasetSize);

            _results.Add(new Dictionary<string, object>
            {
                { "Strategy", strategyName },
                { "Dataset Size", datasetSize },
                { "Cache Hit Rate", (double)hitCount / (hitCount + missCount) * 100 },
                { "Cache Miss Rate", (double)missCount / (hitCount + missCount) * 100 },
                { "Evictions", evictionCount },
                { "Min TTL", minTTL },
                { "Max TTL", maxTTL },
                { "Average TTL", averageFreshness },
                { "Expired Keys", expiredKeys },
                { "Total Write Time (ms)", writeTime },
                { "Average Write Time (ms/key)", averageWriteTime },
                { "Total Read Time (ms)", readTime },
                { "Average Read Time (ms/key)", averageReadTime },
                { "Initial Memory Usage (bytes)", memoryResults.InitialMemoryUsage },
                { "Memory After Random Access (bytes)", memoryResults.MemoryAfterRandomAccess },
                { "Final Memory Usage (bytes)", memoryResults.FinalMemoryUsage },
                { "Fragmentation Ratio", memoryResults.FragmentationRatio },
                { "Process CPU Usage (%)", cpuUsagePercent },
                { "Process Memory Delta (bytes)", deltaWorkingSet }
            });

            if (cacheClient is AdaptiveCacheClient adpt)
            {
                adpt.CacheManager.DisableCacheManager();
            }
        }

        private async Task<(int hitCount, int missCount, double averageFreshness, double minTTL, double maxTTL, int evictions, int expiredKeysCount)> RunMainExperiment(string strategyName, object cacheClient, int datasetSize)
        {
            await CleanAllDatabases();
            await PrepareDatabaseForExperiment(strategyName, cacheClient, datasetSize);

            if (cacheClient is AdaptiveCacheClient adaptiveClient)
            {
                adaptiveClient.CacheManager.EnableCacheManager();
            }

            TimeSpan warmupDuration = TimeSpan.FromSeconds(30);
            DateTime warmupStopTime = DateTime.UtcNow.Add(warmupDuration);
            while (DateTime.UtcNow < warmupStopTime)
            {
                await PerformRandomAccess(cacheClient, datasetSize);
                await Task.Delay(1000);
            }

            await Task.Delay(5000);

            
            var (hitCount, missCount, averageFreshness, minTTL, maxTTL, expired, withoutTTL) = await MeasureHitMissAndFreshness(cacheClient, datasetSize, strategyName, readRatio: ReadRatio);

            var evictions = 0;
            var expiredKeysCount = 0;

            if (cacheClient is AdaptiveCacheClient adaptiveClient2)
            {
                evictions = adaptiveClient2.CacheManager.EvictionCount;
                expiredKeysCount = adaptiveClient2.ExpiredKeys;
                adaptiveClient2.CacheManager.DisableCacheManager();
            }
            else
            {
                var server = _redis.GetServer(_redis.GetEndPoints().First());
                var stats = await server.InfoAsync("stats");
                var evictedKeys = stats.FirstOrDefault(section => section.Key == "Stats")?
                                  .FirstOrDefault(entry => entry.Key == "evicted_keys").Value;

                var expiredKeys = stats.FirstOrDefault(section => section.Key == "Stats")?
                                  .FirstOrDefault(entry => entry.Key == "expired_keys").Value;

                evictions = int.TryParse(evictedKeys, out evictions) ? evictions : 0;
                expiredKeysCount = int.TryParse(expiredKeys, out expiredKeysCount) ? expiredKeysCount : 0;
            }

            return (hitCount, missCount, averageFreshness, minTTL, maxTTL, evictions, expiredKeysCount);
        }

        private async Task<(long writeTime, long readTime, double averageWriteTime, double averageReadTime)>
            RunOperationTimesExperiment(string strategyName, object cacheClient, int datasetSize)
        {
            await CleanAllDatabases();
            await PrepareDatabaseForExperiment(strategyName, cacheClient, datasetSize);
            return await MeasureOperationTimes(strategyName, cacheClient, datasetSize);
        }

        private async Task<(long InitialMemoryUsage, long MemoryAfterRandomAccess, long FinalMemoryUsage, double FragmentationRatio)>
            RunMemoryUsageExperiment(string strategyName, object cacheClient, int datasetSize)
        {
            await CleanAllDatabases();
            Console.WriteLine("Preparing database for memory usage experiment...");
            await PrepareDatabaseForExperiment(strategyName, cacheClient, datasetSize);

            long initialMemoryUsage = await MeasureMemoryUsageDuringExperiment("after data preparation");

            Console.WriteLine("Performing random access to simulate workload...");
            await PerformRandomAccess(cacheClient, datasetSize);

            long memoryAfterRandomAccess = await MeasureMemoryUsageDuringExperiment("after random access");

            Console.WriteLine("Adding additional data to test eviction and memory usage...");
            await OverflowCache(cacheClient, datasetSize);

            long finalMemoryUsage = await MeasureMemoryUsageDuringExperiment("final memory usage");

            double fragmentationRatio = await GetMemoryFragmentationRatio();

            return (initialMemoryUsage, memoryAfterRandomAccess, finalMemoryUsage, fragmentationRatio);
        }

        private async Task<double> RunCPUUsageExperiment(string strategyName, object cacheClient, int datasetSize)
        {
            await CleanAllDatabases();
            Console.WriteLine("Preparing database for CPU usage experiment...");
            await PrepareDatabaseForExperiment(strategyName, cacheClient, datasetSize);

            var currentProcess = Process.GetCurrentProcess();
            TimeSpan cpuStart = currentProcess.TotalProcessorTime;

            var stopwatch = Stopwatch.StartNew();

            Console.WriteLine("Performing random access to simulate workload...");
            await PerformRandomAccess(cacheClient, datasetSize);

            Console.WriteLine("Adding additional data to test eviction and memory usage...");
            await OverflowCache(cacheClient, datasetSize);

            stopwatch.Stop();

            TimeSpan cpuEnd = currentProcess.TotalProcessorTime;

            double usedCpuMs = (cpuEnd - cpuStart).TotalMilliseconds;
            double elapsedMs = stopwatch.ElapsedMilliseconds;

            double cpuUsagePercent = (usedCpuMs / elapsedMs) * 100.0;
            Console.WriteLine($"[CPU] Strategy: {strategyName}, Dataset: {datasetSize}, CPU Usage: {cpuUsagePercent:F2}%");

            return cpuUsagePercent;
        }

        private async Task<double> RunRAMUsageExperiment(string strategyName, object cacheClient, int datasetSize)
        {
            await CleanAllDatabases();
            Console.WriteLine("Preparing database for CPU usage experiment...");
            await PrepareDatabaseForExperiment(strategyName, cacheClient, datasetSize);

            GC.Collect();
            GC.WaitForPendingFinalizers();
            await Task.Delay(500);

            var currentProcess = Process.GetCurrentProcess();
            currentProcess.Refresh();

            long memStart = currentProcess.WorkingSet64;


            Console.WriteLine("Performing random access to simulate workload...");
            await PerformRandomAccess(cacheClient, datasetSize);

            Console.WriteLine("Adding additional data to test eviction and memory usage...");
            await OverflowCache(cacheClient, datasetSize);

            await Task.Delay(1000);
            currentProcess.Refresh();
            long memEnd = currentProcess.WorkingSet64;

            long memoryDelta = memEnd - memStart;

            Console.WriteLine($"[RAM] Strategy: {strategyName}: Memory Delta: {memoryDelta / 1024.0 / 1024.0:F2} MB");

            return memoryDelta;
        }

        private async Task PrepareDatabaseForExperiment(string strategyName, object cacheClient, int datasetSize)
        {
            var random = new Random();
            var keys = Enumerable.Range(0, datasetSize).ToList();

            await ProcessInBatches(keys, async i =>
            {
                string key = $"key:{i}";
                var obj = new ComplexObject
                {
                    Id = i,
                    Name = $"Object-{i}",
                    Timestamp = DateTime.UtcNow
                };

                if (cacheClient is AdaptiveCacheClient adaptiveClient)
                {
                    await adaptiveClient.StoreObjectAsync(key, obj);
                    if (strategyName != "NoEviction")
                    {
                        await adaptiveClient.SetKeyTTLAsync(key, TimeSpan.FromSeconds(random.Next(60, 120)));
                    }
                }
                else
                {
                    string serializedObj = System.Text.Json.JsonSerializer.Serialize(obj);
                    if (strategyName != "NoEviction")
                    {
                        await _database.StringSetAsync(key, serializedObj,
                            TimeSpan.FromSeconds(random.Next(60, 120)));
                    }
                    else
                    {
                        await _database.StringSetAsync(key, serializedObj);
                    }
                }
            });
        }

        private async Task<(int hitCount, int missCount, double averageTTL, double minTTL, double maxTTL, int expiredKeys, int keysWithoutTTL)>
            MeasureHitMissAndFreshness(object cacheClient, int datasetSize, string strategyName, int readRatio = 80)
        {
            int hitCount = 0, missCount = 0;
            double totalTTL = 0;
            double minTTL = double.MaxValue, maxTTL = double.MinValue;
            int processedKeys = 0, expiredKeys = 0, keysWithoutTTL = 0;
            var random = new Random();

            var allKeys = Enumerable.Range(0, datasetSize).Select(i => $"key:{i}").ToList();
            int hotCount = datasetSize / 5; // 20%
            var hotKeys = allKeys.Take(hotCount).ToList();
            var coldKeys = allKeys.Skip(hotCount).ToList();

            var operations = Enumerable.Range(0, datasetSize).ToList();

            object syncLock = new object();

            await ProcessInBatches(operations, async _ =>
            {
                string key = random.Next(100) < readRatio
                    ? hotKeys[random.Next(hotKeys.Count)]
                    : coldKeys[random.Next(coldKeys.Count)];

                bool isHit = false;
                TimeSpan newTTL = TimeSpan.FromSeconds(random.Next(60, 120));

                if (cacheClient is AdaptiveCacheClient adaptiveClient)
                {
                    var result = await adaptiveClient.GetObjectAsync<ComplexObject>(key);
                    isHit = (result != null);
                    if (!isHit)
                    {
                        Interlocked.Increment(ref missCount);
                        var obj = new ComplexObject
                        {
                            Id = random.Next(datasetSize),
                            Name = $"Reloaded-{key}",
                            Timestamp = DateTime.UtcNow
                        };
                        await adaptiveClient.StoreObjectAsync(key, obj);
                        if (strategyName != "NoEviction")
                        {
                            await adaptiveClient.SetKeyTTLAsync(key, newTTL);
                        }
                    }
                }
                else
                {
                    var result = await _database.StringGetAsync(key);
                    isHit = !result.IsNullOrEmpty;
                    if (!isHit)
                    {
                        Interlocked.Increment(ref missCount);
                        var obj = new ComplexObject
                        {
                            Id = random.Next(datasetSize),
                            Name = $"Reloaded-{key}",
                            Timestamp = DateTime.UtcNow
                        };
                        string serializedObj = System.Text.Json.JsonSerializer.Serialize(obj);
                        if (strategyName != "NoEviction")
                        {
                            await _database.StringSetAsync(key, serializedObj, newTTL);
                        }
                        else
                        {
                            await _database.StringSetAsync(key, serializedObj);
                        }
                    }
                }

                if (isHit)
                {
                    Interlocked.Increment(ref hitCount);
                }

                TimeSpan? ttl = null;
                if (cacheClient is AdaptiveCacheClient adaptiveClient2)
                {
                    ttl = await adaptiveClient2.GetKeyTTLAsync(key);
                }
                else
                {
                    ttl = await _database.KeyTimeToLiveAsync(key);
                }

                if (ttl.HasValue)
                {
                    double ttlSeconds = ttl.Value.TotalSeconds;
                    if (ttlSeconds > 0)
                    {
                        lock (syncLock)
                        {
                            totalTTL += ttlSeconds;
                            minTTL = Math.Min(minTTL, ttlSeconds);
                            maxTTL = Math.Max(maxTTL, ttlSeconds);
                            processedKeys++;
                        }
                    }
                    else
                    {
                        Interlocked.Increment(ref expiredKeys);
                    }
                }
                else
                {
                    Interlocked.Increment(ref keysWithoutTTL);
                }
            }, 1);

            double averageTTL = processedKeys > 0 ? totalTTL / processedKeys : 0;
            minTTL = processedKeys > 0 ? minTTL : 0;
            maxTTL = processedKeys > 0 ? maxTTL : 0;

            Console.WriteLine($"[Combined Metrics] Average TTL: {averageTTL}, Min TTL: {minTTL}, Max TTL: {maxTTL}, " +
                              $"Expired Keys: {expiredKeys}, Keys without TTL: {keysWithoutTTL}");
            Console.WriteLine($"[Hit/Miss] Hits: {hitCount}, Misses: {missCount}");

            return (hitCount, missCount, averageTTL, minTTL, maxTTL, expiredKeys, keysWithoutTTL);
        }

        private async Task<(long writeTime, long readTime, double averageWriteTime, double averageReadTime)>
            MeasureOperationTimes(string strategyName, object cacheClient, int datasetSize)
        {
            var stopwatch = new Stopwatch();
            var random = new Random();

            var keys = Enumerable.Range(0, datasetSize).Select(i => $"key:{i}").ToList();

            stopwatch.Start();
            await ProcessInBatches(keys, async key =>
            {
                var obj = new ComplexObject
                {
                    Id = random.Next(datasetSize),
                    Name = $"Object-{key}",
                    Timestamp = DateTime.UtcNow
                };

                if (cacheClient is AdaptiveCacheClient adaptiveClient)
                {
                    await adaptiveClient.StoreObjectAsync(key, obj);
                }
                else
                {
                    string serializedObj = System.Text.Json.JsonSerializer.Serialize(obj);
                    await _database.StringSetAsync(key, serializedObj);
                }
            }, 1);
            stopwatch.Stop();
            long writeTime = stopwatch.ElapsedMilliseconds;

            var hotKeys = keys.Take(datasetSize / 5).ToList();
            var coldKeys = keys.Skip(datasetSize / 5).ToList();
            var readKeys = Enumerable.Range(0, datasetSize).Select(_ =>
                random.Next(100) < 80
                    ? hotKeys[random.Next(hotKeys.Count)]
                    : coldKeys[random.Next(coldKeys.Count)]
            ).ToList();

            stopwatch.Restart();
            await ProcessInBatches(readKeys, async key =>
            {
                if (cacheClient is AdaptiveCacheClient adaptiveClient)
                {
                    await adaptiveClient.GetObjectAsync<ComplexObject>(key);
                }
                else
                {
                    await _database.StringGetAsync(key);
                }
            }, 1);
            stopwatch.Stop();
            long readTime = stopwatch.ElapsedMilliseconds;

            double averageWriteTime = (double)writeTime / datasetSize;
            double averageReadTime = (double)readTime / datasetSize;

            return (writeTime, readTime, averageWriteTime, averageReadTime);
        }

        private async Task PerformRandomAccess(object cacheClient, int datasetSize)
        {
            var totalRequests = datasetSize / 2;
            Console.WriteLine($"Performing {totalRequests} random accesses...");
            var random = new Random();

            var keys = Enumerable.Range(0, datasetSize).Select(i => $"key:{i}").ToArray();
            var hotKeys = keys.Take(datasetSize / 5).ToArray();
            var coldKeys = keys.Skip(datasetSize / 5).ToArray();

            var requests = Enumerable.Range(0, totalRequests).Select(_ =>
            {
                string key = random.Next(100) < 80
                    ? hotKeys[random.Next(hotKeys.Length)]
                    : coldKeys[random.Next(coldKeys.Length)];
                return key;
            }).ToList();

            await ProcessInBatches(requests, async key =>
            {
                if (cacheClient is AdaptiveCacheClient adaptiveClient)
                {
                    await adaptiveClient.GetObjectAsync<ComplexObject>(key);
                }
                else
                {
                    await _database.StringGetAsync(key);
                }
            });
        }

        private async Task OverflowCache(object cacheClient, int datasetSize)
        {
            var random = new Random();
            var indices = Enumerable.Range(datasetSize, datasetSize * 2).ToList();

            await ProcessInBatches(indices, async i =>
            {
                string key = $"key:{i}";
                var obj = new ComplexObject
                {
                    Id = i,
                    Name = $"Object-{key}",
                    Timestamp = DateTime.UtcNow
                };

                if (cacheClient is AdaptiveCacheClient adaptiveClient)
                {
                    await adaptiveClient.StoreObjectAsync(key, obj);
                    await adaptiveClient.SetKeyTTLAsync(key, TimeSpan.FromSeconds(random.Next(60, 120)));
                }
                else
                {
                    string serializedObj = System.Text.Json.JsonSerializer.Serialize(obj);
                    await _database.StringSetAsync(key, serializedObj, TimeSpan.FromSeconds(random.Next(60, 120)));
                }
            });
        }


        private async Task<long> MeasureMemoryUsageDuringExperiment(string stageDescription)
        {
            var server = _redis.GetServer(_redis.GetEndPoints().First());
            var memoryInfo = await server.InfoAsync("memory");
            var usedMemory = memoryInfo.FirstOrDefault(section => section.Key == "Memory")?
                .FirstOrDefault(entry => entry.Key == "used_memory").Value;

            if (long.TryParse(usedMemory, out var memoryUsage))
            {
                Console.WriteLine($"Memory usage {stageDescription}: {memoryUsage} bytes.");
                return memoryUsage;
            }

            Console.WriteLine($"Failed to retrieve memory usage {stageDescription}.");
            return 0;
        }

        private async Task<double> GetMemoryFragmentationRatio()
        {
            var server = _redis.GetServer(_redis.GetEndPoints().First());
            var memoryInfo = await server.InfoAsync("memory");
            var fragmentationRatio = memoryInfo.FirstOrDefault(section => section.Key == "Memory")?
                .FirstOrDefault(entry => entry.Key == "mem_fragmentation_ratio").Value;

            return double.TryParse(fragmentationRatio, out var ratio) ? ratio : 0.0;
        }

        private async Task CleanAllDatabases()
        {
            Console.WriteLine("Cleaning all databases...");
            var server = _redis.GetServer(_redis.GetEndPoints().First());
            await server.FlushDatabaseAsync();
            server.Execute("CONFIG", "RESETSTAT");
            Console.WriteLine("All databases cleaned.");
        }

        private void SaveResultsToCsv(string filePath)
        {
            Console.WriteLine($"Saving results to {filePath}...");
            using var writer = new StreamWriter(filePath);
            var headers = _results.First().Keys;
            writer.WriteLine(string.Join(",", headers));

            foreach (var result in _results)
            {
                writer.WriteLine(string.Join(",", result.Values));
            }
            Console.WriteLine("Results saved.");
        }

        private async Task ProcessInBatches<T>(IEnumerable<T> items, Func<T, Task> action, int maxDegreeOfParallelism = 10)
        {
            var tasks = new List<Task>();
            using (var semaphore = new SemaphoreSlim(maxDegreeOfParallelism))
            {
                foreach (var item in items)
                {
                    await semaphore.WaitAsync();
                    tasks.Add(Task.Run(async () =>
                    {
                        try
                        {
                            await action(item);
                        }
                        finally
                        {
                            semaphore.Release();
                        }
                    }));
                }
                await Task.WhenAll(tasks);
            }
        }

        private AdaptiveCacheClientOptions GetDefaultAdaptiveCacheClientOptions()
        {
            return new AdaptiveCacheClientOptions
            {
                MaxTTL = TimeSpan.FromSeconds(120),
                CleanupInterval = TimeSpan.FromSeconds(15),
                DecayLambda = 0.2,
                BaseTTL = TimeSpan.FromSeconds(60),
                AdaptiveCacheManagerOptions = GetDefaultAdaptiveCacheManagerOptions()
            };
        }

        private AdaptiveCacheManagerOptions GetDefaultAdaptiveCacheManagerOptions()
        {
            return new AdaptiveCacheManagerOptions
            {
                CleanupInterval = TimeSpan.FromSeconds(15),
                AgeWeight = 0.3,
                FrequencyWeight = 0.5,
                MemoryWeight = 0.2,
                MaxCacheMemory = DefaultMemoryLimitMB * 1024L * 1024L,
                DecayLambda = 0.2,
                PMemoryThreshold = 0.85
            };
        }

        private object ConfigureRedisPolicy(string policy, int memoryMB)
        {
            var server = _redis.GetServer(_redis.GetEndPoints().First());
            server.ConfigSet("maxmemory", $"{memoryMB}mb");
            server.ConfigSet("maxmemory-policy", policy);
            Console.WriteLine($"Redis policy set to: {policy}, memory limit: {memoryMB} MB");
            return null;
        }

        private int CalculateMemoryLimit(int datasetSize, string strategy)
        {
            const int AvgObjectSizeBytes = 3000;
            double fitPercentage = 0.90;

            long totalDataSizeBytes = datasetSize * AvgObjectSizeBytes;
            long requiredMemoryForFit = (long)(totalDataSizeBytes / fitPercentage);

            if (strategy == "Adaptive")
            {
                double adaptiveOverheadFactor = 1.42;
                requiredMemoryForFit = (long)(requiredMemoryForFit * adaptiveOverheadFactor);
            }

            int memoryLimitMB = (int)(requiredMemoryForFit / (1024.0 * 1024.0));

            return memoryLimitMB;
        }

        public void Dispose()
        {
            _redis?.Dispose();
        }
    }

    public static class Program
    {
        public static async Task Main(string[] args)
        {
            var experiment = new ExperimentRunner("localhost:6380,allowAdmin=true,syncTimeout=250000,asyncTimeout=250000");
            await experiment.Run();
            experiment.Dispose();
        }
    }
}
